// import axios from "axios";

// const request = axios.create({
//   baseURL: "http://localhost:8080/api",
// });

// export const Block = async (BlockInfo) => {
//   return await request.post("/block", BlockInfo);
// };
