const MetamaskComponent = () => {
  return <></>;
};

export default MetamaskComponent;
