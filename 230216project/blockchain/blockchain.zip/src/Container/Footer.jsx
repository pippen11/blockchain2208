import FooterComponent from "../Components/Footer";

const FooterContainer = () => {
  return (
    <>
      <FooterComponent></FooterComponent>
    </>
  );
};

export default FooterContainer;
