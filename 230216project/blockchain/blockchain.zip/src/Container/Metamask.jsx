import MetamaskComponent from "../Components/Metamask";

const MetamaskContainer = () => {
  return <MetamaskComponent></MetamaskComponent>;
};

export default MetamaskContainer;
